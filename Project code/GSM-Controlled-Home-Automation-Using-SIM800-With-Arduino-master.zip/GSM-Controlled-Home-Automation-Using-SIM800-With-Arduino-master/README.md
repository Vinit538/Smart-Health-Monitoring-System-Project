# GSM-Controlled-Home-Automation-Using-SIM800-With-Arduino
Gsm based Home Automation are used to control Home devices Like TV , Lights , AC etc.  just take an example , if there are sunny day and you want to Turn on your AC Before you Even Walk In the Door.  So for this you have to send a SMS then AC will be turn on.  It is simple way to save electricity and make our home smart.

For more information 

Please go to the link : https://www.youtube.com/watch?v=Ljod3rH7WRE&t=58s

Watch my youtube channel :- http://youtube.com/vishalsoniindia
